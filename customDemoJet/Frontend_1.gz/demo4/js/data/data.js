/**
 * Copyright (c) 2014, 2017, Oracle and/or its affiliates.
 * The Universal Permissive License (UPL), Version 1.0
 */
define(['ojs/ojcore', 'knockout', 'jquery'],
        function (oj, ko, $)
        {
            function fetchData(url) {
                return $.getJSON(url);
            }
            
            function fetchPerson(url) {
                  return $.getJSON(url);
            }

            function getToken(url){
                console.log("call get token");
                var token;
			return $.ajax({
				url: url,
				datatype: 'json',
				type: 'post',
				headers: {'Authorization': 'Basic YnJvd3Nlcjo='},
				async: false,
				data: {
					scope: 'ui',
					username: 'oracle',
					password: 'welcome1',
					grant_type: 'password'
				}/*,
				success: function (data) {
					
					console.log("success get:"+ko.toJSON(data));
					token = data.access_token;
				},
				error: function () {
					console.log("get token err");
				}*/
			});
            }
            function getDataUseToken(url,token,data){
                console.log("call "+url+" use token "+ token +" send data "+data);
            		return	$.ajax({
				url: url,
				datatype: 'json',
				headers: {'Authorization': 'Bearer ' + token,'Access-Control-Allow-Origin':'*'},
				data: data, 
				type: 'get',
				contentType: 'application/json;charset=UTF-8',
				async: false				
			});
            }
            function sendDataUseToken(url,token,data,type){
                console.log("call "+url+" use token "+ token +" send data "+data);
            		return	$.ajax({
				url: url,
				datatype: 'json',
//				headers: {'Authorization': 'Bearer ' + token,'Access-Control-Allow-Origin':'*'},
				data: data, 
				type: type,
				contentType: 'application/json;charset=UTF-8',
				async: false				
			});
            }
            return {fetchData: fetchData,getToken: getToken,getDataUseToken: getDataUseToken,sendDataUseToken: sendDataUseToken};
        });


                